#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

struct request_header { uint64_t pk_length, signed_message_length; };
struct response_header {
    int32_t result, accepted;
    uint64_t recovered_length, expected_length;
    uint32_t stderr_length;
};

static unsigned char *read_file(const char *path, size_t *length) {
    FILE *file = fopen(path, "rb");
    unsigned char *buffer;
    long end;
    if (file == NULL || fseek(file, 0, SEEK_END) != 0) return NULL;
    end = ftell(file);
    if (end < 0 || fseek(file, 0, SEEK_SET) != 0) return NULL;
    buffer = malloc((size_t)end + 1);
    if (buffer == NULL || (end > 0 && fread(buffer, (size_t)end, 1, file) != 1)) return NULL;
    fclose(file); *length = (size_t)end; return buffer;
}

static int transfer(int fd, void *buffer, size_t length, int writing) {
    unsigned char *cursor = buffer;
    while (length != 0) {
        ssize_t count = writing ? write(fd, cursor, length) : read(fd, cursor, length);
        if (count <= 0) return 0;
        cursor += count; length -= (size_t)count;
    }
    return 1;
}

int main(int argc, char **argv) {
    struct sockaddr_un address = {0};
    struct request_header request;
    struct response_header response;
    unsigned char *pk, *sm;
    size_t pk_length = 0, sm_length = 0;
    char trace[4096];
    const char *socket_path = getenv("H7_VERIFY_SOCKET");
    int connection;
    if (argc != 3 || socket_path == NULL || strlen(socket_path) >= sizeof(address.sun_path)) return 2;
    pk = read_file(argv[1], &pk_length); sm = read_file(argv[2], &sm_length);
    if (pk == NULL || sm == NULL) return 2;
    request = (struct request_header){pk_length, sm_length};
    connection = socket(AF_UNIX, SOCK_STREAM, 0);
    address.sun_family = AF_UNIX; strcpy(address.sun_path, socket_path);
    if (connection < 0 || connect(connection, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        !transfer(connection, &request, sizeof(request), 1) ||
        !transfer(connection, pk, pk_length, 1) ||
        !transfer(connection, sm, sm_length, 1) ||
        !transfer(connection, &response, sizeof(response), 0) ||
        response.stderr_length >= sizeof(trace) ||
        !transfer(connection, trace, response.stderr_length, 0)) return 2;
    if (response.stderr_length != 0) fwrite(trace, response.stderr_length, 1, stderr);
    printf("result=%d recovered_length=%llu expected_length=%llu accepted=%d\n",
           response.result, (unsigned long long)response.recovered_length,
           (unsigned long long)response.expected_length, response.accepted);
    free(pk); free(sm); close(connection);
    return response.accepted ? 0 : 1;
}

