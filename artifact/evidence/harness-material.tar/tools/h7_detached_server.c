#include <api.h>
#include <sig.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

struct request_header {
    uint64_t pk_length;
    uint64_t signature_length;
    uint64_t message_length;
    uint64_t declared_signature_length;
};

static int read_all(int fd, void *buffer, size_t length) {
    unsigned char *cursor = buffer;
    while (length != 0) {
        ssize_t count = read(fd, cursor, length);
        if (count <= 0) return 0;
        cursor += count;
        length -= (size_t)count;
    }
    return 1;
}

static int write_all(int fd, const void *buffer, size_t length) {
    const unsigned char *cursor = buffer;
    while (length != 0) {
        ssize_t count = write(fd, cursor, length);
        if (count <= 0) return 0;
        cursor += count;
        length -= (size_t)count;
    }
    return 1;
}

int main(int argc, char **argv) {
    struct sockaddr_un address = {0};
    int listener;

    if (argc != 2 || strlen(argv[1]) >= sizeof(address.sun_path)) return 2;
    listener = socket(AF_UNIX, SOCK_STREAM, 0);
    if (listener < 0) return 2;
    address.sun_family = AF_UNIX;
    strcpy(address.sun_path, argv[1]);
    unlink(address.sun_path);
    if (bind(listener, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        listen(listener, 8) != 0) return 2;

    for (;;) {
        struct request_header header;
        unsigned char *pk = NULL, *signature = NULL, *message = NULL;
        int32_t result = 2;
        int connection = accept(listener, NULL, NULL);
        if (connection < 0) continue;
        if (!read_all(connection, &header, sizeof(header))) goto respond;
        if (header.pk_length != CRYPTO_PUBLICKEYBYTES ||
            header.signature_length > SIZE_MAX ||
            header.message_length > SIZE_MAX ||
            header.declared_signature_length > header.signature_length) goto respond;
        pk = malloc((size_t)header.pk_length + 1);
        signature = malloc((size_t)header.signature_length + 1);
        message = malloc((size_t)header.message_length + 1);
        if (pk == NULL || signature == NULL || message == NULL) goto respond;
        if (!read_all(connection, pk, (size_t)header.pk_length) ||
            !read_all(connection, signature, (size_t)header.signature_length) ||
            !read_all(connection, message, (size_t)header.message_length)) goto respond;
        result = sqisign_verify(message, header.message_length, signature,
                                header.declared_signature_length, pk);
respond:
        write_all(connection, &result, sizeof(result));
        free(pk);
        free(signature);
        free(message);
        close(connection);
    }
}

