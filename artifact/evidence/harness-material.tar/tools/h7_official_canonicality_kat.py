#!/usr/bin/env python3
"""Probe whether discarded Fp canonicality masks reach accepted SQIsign objects.

For each frozen KAT tuple, this experiment replaces one serialized Fp component
by either canonical zero or the noncanonical integer p. At the pinned reference
and Broadwell authorities, fp_decode maps both byte strings to internal zero;
its canonicality mask distinguishes them, but the enclosing fp2 deserializer
does not propagate that mask.

The verifier-level question is whether both distinct byte strings can reach an
accepting state. Paired acceptance is a concrete accepted-encoding collision.
Paired rejection means a later semantic predicate rejects that forced-zero
object. Diagnostic-only instrumentation names the first rejection predicate so
negative evidence remains explanatory rather than an opaque return code.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
from typing import Any


PARAMETER_PROFILES: dict[int, dict[str, int | str]] = {
    1: {
        "fp_bytes": 32,
        "prime_hex": "4ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
        "public_key_bytes": 65,
        "signature_bytes": 148,
        "kat_secret_key_bytes": 353,
    },
    3: {
        "fp_bytes": 48,
        "prime_hex": "40ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
        "public_key_bytes": 97,
        "signature_bytes": 224,
        "kat_secret_key_bytes": 529,
    },
    5: {
        "fp_bytes": 64,
        "prime_hex": "1afffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
        "public_key_bytes": 129,
        "signature_bytes": 292,
        "kat_secret_key_bytes": 701,
    },
}
REJECTION_PREFIX = "H7_REJECT="


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_rsp(path: Path) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    current: dict[str, str] = {}
    required = {"mlen", "msg", "pk", "smlen", "sm"}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            if current.get("count") is not None and required <= current.keys():
                records.append(current)
                current = {}
            continue
        if " = " not in line:
            continue
        key, value = line.split(" = ", 1)
        current[key.strip()] = value.strip()
    if current.get("count") is not None and required <= current.keys():
        records.append(current)
    return records


def first_rejection_stage(stderr: str) -> str | None:
    for line in stderr.splitlines():
        if line.startswith(REJECTION_PREFIX):
            return line[len(REJECTION_PREFIX) :].strip()
    return None


def verify(
    verifier: Path,
    pk: bytes,
    sm: bytes,
    work: Path,
    tag: str,
    timeout_seconds: int,
) -> dict[str, Any]:
    pk_path = work / f"{tag}.pk"
    sm_path = work / f"{tag}.sm"
    pk_path.write_bytes(pk)
    sm_path.write_bytes(sm)
    completed = subprocess.run(
        [str(verifier), str(pk_path), str(sm_path)],
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
    )
    if completed.returncode not in (0, 1):
        classification = "abnormal"
    elif completed.returncode == 0:
        classification = "accepted"
    else:
        classification = "rejected"
    return {
        "classification": classification,
        "returncode": completed.returncode,
        "rejection_stage": first_rejection_stage(completed.stderr),
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def components(fp_bytes: int) -> tuple[tuple[str, str, int], ...]:
    return (
        ("public_key.A.real", "pk", 0),
        ("public_key.A.imag", "pk", fp_bytes),
        ("signature.E_aux_A.real", "sm", 0),
        ("signature.E_aux_A.imag", "sm", fp_bytes),
    )


def replace_component(
    pk: bytes,
    sm: bytes,
    owner: str,
    offset: int,
    replacement: bytes,
    fp_bytes: int,
) -> tuple[bytes, bytes, bytes]:
    target = bytearray(pk if owner == "pk" else sm)
    original = bytes(target[offset : offset + fp_bytes])
    if len(original) != fp_bytes:
        raise ValueError(f"component {owner}@{offset} exceeds serialized input")
    target[offset : offset + fp_bytes] = replacement
    if owner == "pk":
        return bytes(target), sm, original
    return pk, bytes(target), original


def profile_for(level: int) -> dict[str, int | str]:
    profile = PARAMETER_PROFILES[level]
    fp_bytes = int(profile["fp_bytes"])
    prime = int(str(profile["prime_hex"]), 16)
    if prime.bit_length() > 8 * fp_bytes:
        raise ValueError(f"level {level} prime does not fit the declared field encoding")
    return profile


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rsp", type=Path, required=True)
    parser.add_argument("--verifier", type=Path, required=True)
    parser.add_argument("--official-revision", required=True)
    parser.add_argument(
        "--parameter-level",
        type=int,
        choices=sorted(PARAMETER_PROFILES),
        required=True,
    )
    parser.add_argument("--implementation", choices=("ref", "broadwell"), required=True)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--verify-timeout", type=int, default=180)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    profile = profile_for(args.parameter_level)
    fp_bytes = int(profile["fp_bytes"])
    public_key_bytes = int(profile["public_key_bytes"])
    signature_bytes = int(profile["signature_bytes"])
    prime = int(str(profile["prime_hex"]), 16)
    zero_fp = bytes(fp_bytes)
    p_little_endian = prime.to_bytes(fp_bytes, "little")
    if zero_fp == p_little_endian:
        raise SystemExit("canonical zero and noncanonical p encodings unexpectedly coincide")

    records = parse_rsp(args.rsp)
    if not records:
        raise SystemExit("no KAT records parsed")
    records = records[: args.limit]

    outcomes: list[dict[str, Any]] = []
    baseline_failures: list[dict[str, Any]] = []
    accepted_collisions: list[dict[str, Any]] = []
    verdict_divergences: list[dict[str, Any]] = []
    stage_divergences: list[dict[str, Any]] = []
    abnormal_results: list[dict[str, Any]] = []
    unclassified_rejections: list[dict[str, Any]] = []
    original_zero_components: list[dict[str, Any]] = []
    malformed_records: list[dict[str, Any]] = []
    stage_counts: dict[str, Counter[str]] = defaultdict(Counter)

    with tempfile.TemporaryDirectory(prefix="h7-canonicality-") as tmp:
        work = Path(tmp)
        for record in records:
            count = int(record["count"])
            mlen = int(record["mlen"])
            smlen = int(record["smlen"])
            message = bytes.fromhex(record["msg"])
            pk = bytes.fromhex(record["pk"])
            sm = bytes.fromhex(record["sm"])
            problems: list[str] = []
            if len(message) != mlen:
                problems.append("message length mismatch")
            if len(pk) != public_key_bytes:
                problems.append("public-key length mismatch")
            if len(sm) != smlen:
                problems.append("signed-message length mismatch")
            if smlen - mlen != signature_bytes:
                problems.append("signature length mismatch")
            if mlen > len(sm) or sm[-mlen:] != message:
                problems.append("signed-message tail mismatch")
            if problems:
                malformed_records.append({"count": count, "problems": problems})
                continue

            baseline = verify(
                args.verifier,
                pk,
                sm,
                work,
                f"{count}-baseline",
                args.verify_timeout,
            )
            if baseline["classification"] != "accepted":
                baseline_failures.append({"count": count, "result": baseline})
                continue

            for component, owner, offset in components(fp_bytes):
                zero_pk, zero_sm, original = replace_component(
                    pk, sm, owner, offset, zero_fp, fp_bytes
                )
                p_pk, p_sm, _ = replace_component(
                    pk, sm, owner, offset, p_little_endian, fp_bytes
                )
                zero_result = verify(
                    args.verifier,
                    zero_pk,
                    zero_sm,
                    work,
                    f"{count}-{component}-zero",
                    args.verify_timeout,
                )
                p_result = verify(
                    args.verifier,
                    p_pk,
                    p_sm,
                    work,
                    f"{count}-{component}-p",
                    args.verify_timeout,
                )

                item = {
                    "count": count,
                    "component": component,
                    "original_component_sha256": sha256_bytes(original),
                    "original_was_zero": original == zero_fp,
                    "canonical_zero_encoding": zero_fp.hex(),
                    "noncanonical_p_encoding": p_little_endian.hex(),
                    "encodings_distinct": zero_fp != p_little_endian,
                    "zero_result": zero_result["classification"],
                    "p_result": p_result["classification"],
                    "zero_rejection_stage": zero_result["rejection_stage"],
                    "p_rejection_stage": p_result["rejection_stage"],
                }
                outcomes.append(item)

                if original == zero_fp:
                    original_zero_components.append({"count": count, "component": component})
                if "abnormal" in (
                    zero_result["classification"],
                    p_result["classification"],
                ):
                    abnormal_results.append(
                        {**item, "zero_detail": zero_result, "p_detail": p_result}
                    )
                if zero_result["classification"] != p_result["classification"]:
                    verdict_divergences.append(
                        {**item, "zero_detail": zero_result, "p_detail": p_result}
                    )
                if zero_result["classification"] == p_result["classification"] == "accepted":
                    accepted_collisions.append(item)
                if zero_result["classification"] == "rejected":
                    if zero_result["rejection_stage"] is None:
                        unclassified_rejections.append({**item, "encoding": "zero"})
                    else:
                        stage_counts[component][zero_result["rejection_stage"]] += 1
                if p_result["classification"] == "rejected":
                    if p_result["rejection_stage"] is None:
                        unclassified_rejections.append({**item, "encoding": "p"})
                    else:
                        stage_counts[component][p_result["rejection_stage"]] += 1
                if (
                    zero_result["classification"]
                    == p_result["classification"]
                    == "rejected"
                    and zero_result["rejection_stage"]
                    != p_result["rejection_stage"]
                ):
                    stage_divergences.append(
                        {**item, "zero_detail": zero_result, "p_detail": p_result}
                    )

    summary = {
        "schema": "isogeny-crypto/h7-official-canonicality-kat/v3",
        "official_repository": "SQISign/the-sqisign",
        "official_revision": args.official_revision,
        "parameter_level": args.parameter_level,
        "implementation": args.implementation,
        "parameter_profile": {
            "fp_encoded_bytes": fp_bytes,
            "public_key_bytes": public_key_bytes,
            "signature_bytes": signature_bytes,
            "kat_secret_key_bytes": int(profile["kat_secret_key_bytes"]),
            "prime_hex": str(profile["prime_hex"]),
            "prime_little_endian": p_little_endian.hex(),
        },
        "kat_path": str(args.rsp),
        "kat_sha256": sha256_bytes(args.rsp.read_bytes()),
        "experiment_sha256": sha256_bytes(Path(__file__).read_bytes()),
        "verifier_sha256": sha256_bytes(args.verifier.read_bytes()),
        "record_count": len(records),
        "malformed_record_count": len(malformed_records),
        "malformed_records": malformed_records,
        "baseline_accepted_count": (
            len(records) - len(baseline_failures) - len(malformed_records)
        ),
        "baseline_failures": baseline_failures,
        "component_pair_count": len(outcomes),
        "mutated_verifier_call_count": 2 * len(outcomes),
        "paired_acceptance_count": len(accepted_collisions),
        "paired_rejection_count": sum(
            item["zero_result"] == item["p_result"] == "rejected"
            for item in outcomes
        ),
        "verdict_divergence_count": len(verdict_divergences),
        "rejection_stage_divergence_count": len(stage_divergences),
        "unclassified_rejection_count": len(unclassified_rejections),
        "abnormal_result_count": len(abnormal_results),
        "original_zero_component_count": len(original_zero_components),
        "rejection_stage_counts": {
            component: dict(sorted(counter.items()))
            for component, counter in sorted(stage_counts.items())
        },
        "accepted_collisions": accepted_collisions,
        "verdict_divergences": verdict_divergences,
        "rejection_stage_divergences": stage_divergences,
        "unclassified_rejections": unclassified_rejections,
        "abnormal_results": abnormal_results,
        "original_zero_components": original_zero_components,
        "decoder_mechanism": (
            "At the pinned authority, fp_decode returns a canonicality mask and "
            "zeroes a noncanonical value. Canonical zero and the byte encoding of p "
            "therefore produce internal zero when the enclosing fp2 parser discards the mask."
        ),
        "interpretation": (
            "Paired acceptance is a concrete accepted-encoding collision. Paired rejection "
            "shows that a named later verifier predicate rejects the forced-zero object. "
            "A verdict or rejection-stage divergence contradicts the expected common decoded object."
        ),
        "nonclaims": [
            "Paired rejection does not prove canonicality for all inputs.",
            "A parser-level collision is not a signature forgery unless both encodings reach acceptance.",
            "This experiment covers four Fp components in one published KAT corpus per job.",
            "The diagnostic instrumentation is not a production repair and changes only rejection logging.",
            "No conclusion is drawn for untested revisions, APIs, architectures, or serialized components.",
        ],
        "outcomes": outcomes,
    }
    args.out.write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    report_keys = (
        "parameter_level",
        "implementation",
        "record_count",
        "malformed_record_count",
        "baseline_accepted_count",
        "component_pair_count",
        "mutated_verifier_call_count",
        "paired_acceptance_count",
        "paired_rejection_count",
        "verdict_divergence_count",
        "rejection_stage_divergence_count",
        "unclassified_rejection_count",
        "abnormal_result_count",
        "original_zero_component_count",
        "rejection_stage_counts",
    )
    print(
        json.dumps(
            {key: summary[key] for key in report_keys},
            indent=2,
            sort_keys=True,
        )
    )

    if (
        malformed_records
        or baseline_failures
        or abnormal_results
        or verdict_divergences
        or stage_divergences
        or unclassified_rejections
    ):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
