#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

struct request_header {
    uint64_t pk_length;
    uint64_t signature_length;
    uint64_t message_length;
    uint64_t declared_signature_length;
};

static unsigned char *read_file(const char *path, size_t *length) {
    FILE *file = fopen(path, "rb");
    unsigned char *buffer;
    long end;
    if (file == NULL || fseek(file, 0, SEEK_END) != 0) return NULL;
    end = ftell(file);
    if (end < 0 || fseek(file, 0, SEEK_SET) != 0) return NULL;
    buffer = malloc((size_t)end + 1);
    if (buffer == NULL || (end > 0 && fread(buffer, (size_t)end, 1, file) != 1)) return NULL;
    fclose(file);
    *length = (size_t)end;
    return buffer;
}

static int transfer(int fd, void *buffer, size_t length, int writing) {
    unsigned char *cursor = buffer;
    while (length != 0) {
        ssize_t count = writing ? write(fd, cursor, length) : read(fd, cursor, length);
        if (count <= 0) return 0;
        cursor += count;
        length -= (size_t)count;
    }
    return 1;
}

int main(int argc, char **argv) {
    struct sockaddr_un address = {0};
    struct request_header header;
    unsigned char *pk, *signature, *message;
    size_t pk_length = 0, signature_length = 0, message_length = 0;
    unsigned long long declared;
    char *end = NULL;
    const char *socket_path = getenv("H7_VERIFY_SOCKET");
    int connection;
    int32_t result = 2;

    if (argc != 5 || socket_path == NULL || strlen(socket_path) >= sizeof(address.sun_path)) return 2;
    errno = 0;
    declared = strtoull(argv[4], &end, 10);
    if (errno != 0 || end == argv[4] || *end != '\0') return 2;
    pk = read_file(argv[1], &pk_length);
    signature = read_file(argv[2], &signature_length);
    message = read_file(argv[3], &message_length);
    if (pk == NULL || signature == NULL || message == NULL || declared > signature_length) return 2;
    header = (struct request_header){pk_length, signature_length, message_length, declared};
    connection = socket(AF_UNIX, SOCK_STREAM, 0);
    address.sun_family = AF_UNIX;
    strcpy(address.sun_path, socket_path);
    if (connection < 0 || connect(connection, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        !transfer(connection, &header, sizeof(header), 1) ||
        !transfer(connection, pk, pk_length, 1) ||
        !transfer(connection, signature, signature_length, 1) ||
        !transfer(connection, message, message_length, 1) ||
        !transfer(connection, &result, sizeof(result), 0)) return 2;
    printf("result=%d declared_siglen=%llu signature_file_length=%zu message_length=%zu accepted=%d\n",
           result, declared, signature_length, message_length, result == 0);
    free(pk); free(signature); free(message); close(connection);
    return result == 0 ? 0 : 1;
}

