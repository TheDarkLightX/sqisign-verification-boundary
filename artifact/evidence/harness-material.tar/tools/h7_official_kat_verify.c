// SPDX-License-Identifier: Apache-2.0
/*
 * Verify one binary SQIsign KAT tuple through the NIST API.
 *
 * argv[1] is an exact public-key file; argv[2] is a signed-message file whose
 * first CRYPTO_BYTES bytes are the signature and whose tail is the message.
 * Exit 0 means accepted with an exact recovered-message match. Exit 1 means
 * clean rejection. Exit 2 means harness or I/O failure.
 */

#include <api.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned char *
read_file(const char *path, size_t *length)
{
    FILE *file = fopen(path, "rb");
    unsigned char *buffer = NULL;
    long end;

    if (file == NULL) {
        return NULL;
    }
    if (fseek(file, 0, SEEK_END) != 0) {
        fclose(file);
        return NULL;
    }
    end = ftell(file);
    if (end < 0 || fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        return NULL;
    }
    buffer = malloc((size_t)end + 1);
    if (buffer == NULL) {
        fclose(file);
        return NULL;
    }
    if (end > 0 && fread(buffer, (size_t)end, 1, file) != 1) {
        free(buffer);
        fclose(file);
        return NULL;
    }
    fclose(file);
    *length = (size_t)end;
    return buffer;
}

int
main(int argc, char **argv)
{
    unsigned char *pk = NULL;
    unsigned char *sm = NULL;
    unsigned char *message = NULL;
    size_t pk_length = 0;
    size_t signed_message_length = 0;
    unsigned long long recovered_length = 0;
    size_t expected_message_length;
    int result;
    int accepted;

    if (argc != 3) {
        fprintf(stderr, "usage: %s public-key.bin signed-message.bin\n", argv[0]);
        return 2;
    }

    pk = read_file(argv[1], &pk_length);
    sm = read_file(argv[2], &signed_message_length);
    if (pk == NULL || sm == NULL || pk_length != CRYPTO_PUBLICKEYBYTES ||
        signed_message_length < CRYPTO_BYTES) {
        free(pk);
        free(sm);
        fprintf(stderr, "invalid harness input\n");
        return 2;
    }

    expected_message_length = signed_message_length - CRYPTO_BYTES;
    message = malloc(expected_message_length + 1);
    if (message == NULL) {
        free(pk);
        free(sm);
        return 2;
    }

    result = crypto_sign_open(message,
                              &recovered_length,
                              sm,
                              (unsigned long long)signed_message_length,
                              pk);
    accepted = result == 0 &&
               recovered_length == expected_message_length &&
               memcmp(message, sm + CRYPTO_BYTES, expected_message_length) == 0;

    printf("result=%d recovered_length=%llu expected_length=%zu accepted=%d\n",
           result,
           recovered_length,
           expected_message_length,
           accepted);

    free(pk);
    free(sm);
    free(message);
    return accepted ? 0 : 1;
}
