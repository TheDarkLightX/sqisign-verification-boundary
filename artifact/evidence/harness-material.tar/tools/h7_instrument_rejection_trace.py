#!/usr/bin/env python3
"""Instrument the pinned SQIsign verifier with named rejection gates.

This diagnostic-only transformer validates that every expected upstream snippet
occurs exactly once before modifying the source. The resulting binary preserves
accept/reject control flow and only writes stable stage names immediately before
rejection. Helper-level names precede their enclosing top-level names, allowing
the experiment to classify the first semantic obstruction.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


REPLACEMENTS: tuple[tuple[str, str], ...] = (
    (
        """#include <assert.h>
""",
        """#include <assert.h>
#include <stdio.h>

#define H7_REJECT(stage) do { fprintf(stderr, "H7_REJECT=%s\\n", stage); return 0; } while (0)
""",
    ),
    (
        """    // Compute the basis from the supplied hint
    if (!ec_curve_to_basis_2f_from_hint(&bas_EA, &phi_chall.curve, TORSION_EVEN_POWER, hint_pk)) // canonical
        return 0;
""",
        """    // Compute the basis from the supplied hint
    if (!ec_curve_to_basis_2f_from_hint(&bas_EA, &phi_chall.curve, TORSION_EVEN_POWER, hint_pk)) // canonical
        H7_REJECT("challenge_source_basis_hint");
""",
    ),
    (
        """        if (!ec_ladder3pt(&phi_chall.kernel, sig->chall_coeff, &bas_EA.P, &bas_EA.Q, &bas_EA.PmQ, &phi_chall.curve)) {
            return 0;
        };
""",
        """        if (!ec_ladder3pt(&phi_chall.kernel, sig->chall_coeff, &bas_EA.P, &bas_EA.Q, &bas_EA.PmQ, &phi_chall.curve)) {
            H7_REJECT("challenge_three_point_ladder");
        };
""",
    ),
    (
        """    if (ec_eval_even(E_chall, &phi_chall, NULL, 0))
        return 0;
""",
        """    if (ec_eval_even(E_chall, &phi_chall, NULL, 0))
        H7_REJECT("challenge_even_isogeny_evaluation");
""",
    ),
    (
        """        if (!ec_is_basis_four_torsion(B_chall_can, E_chall)) {
            return 0;
        }
""",
        """        if (!ec_is_basis_four_torsion(B_chall_can, E_chall)) {
            H7_REJECT("commitment_four_torsion_basis");
        }
""",
    ),
    (
        """    return codomain_splits;
""",
        """    if (!codomain_splits)
        fprintf(stderr, "H7_REJECT=commitment_theta_codomain_not_split\\n");
    return codomain_splits;
""",
    ),
    (
        """    if (!check_canonical_basis_change_matrix(sig))
        return 0;
""",
        """    if (!check_canonical_basis_change_matrix(sig))
        H7_REJECT("canonical_basis_change_matrix");
""",
    ),
    (
        """    if (pow_dim2_deg_resp < 0)
        return 0;
""",
        """    if (pow_dim2_deg_resp < 0)
        H7_REJECT("negative_response_length");
""",
    ),
    (
        """    if (pow_dim2_deg_resp == 1)
        return 0;
""",
        """    if (pow_dim2_deg_resp == 1)
        H7_REJECT("forbidden_response_length_one");
""",
    ),
    (
        """    if (!ec_curve_verify_A(&(pk->curve).A))
        return 0;
""",
        """    if (!ec_curve_verify_A(&(pk->curve).A))
        H7_REJECT("public_curve_validity");
""",
    ),
    (
        """    if (!ec_curve_init_from_A(&E_aux, &sig->E_aux_A))
        return 0; // invalid curve
""",
        """    if (!ec_curve_init_from_A(&E_aux, &sig->E_aux_A))
        H7_REJECT("auxiliary_curve_validity");
""",
    ),
    (
        """    if (!compute_challenge_verify(&E_chall, sig, &pk->curve, pk->hint_pk)) {
        return 0;
    }
""",
        """    if (!compute_challenge_verify(&E_chall, sig, &pk->curve, pk->hint_pk)) {
        H7_REJECT("challenge_reconstruction");
    }
""",
    ),
    (
        """    if (!challenge_and_aux_basis_verify(&B_chall_can, &B_aux_can, &E_chall, &E_aux, sig, pow_dim2_deg_resp)) {
        return 0;
    }
""",
        """    if (!challenge_and_aux_basis_verify(&B_chall_can, &B_aux_can, &E_chall, &E_aux, sig, pow_dim2_deg_resp)) {
        H7_REJECT("challenge_or_auxiliary_basis");
    }
""",
    ),
    (
        """        if (!two_response_isogeny_verify(&E_chall, &B_chall_can, sig, pow_dim2_deg_resp)) {
            return 0;
        }
""",
        """        if (!two_response_isogeny_verify(&E_chall, &B_chall_can, sig, pow_dim2_deg_resp)) {
            H7_REJECT("two_response_isogeny");
        }
""",
    ),
    (
        """    if (!compute_commitment_curve_verify(&E_com, &B_chall_can, &B_aux_can, &E_chall, &E_aux, pow_dim2_deg_resp))
        return 0;
""",
        """    if (!compute_commitment_curve_verify(&E_com, &B_chall_can, &B_aux_can, &E_chall, &E_aux, pow_dim2_deg_resp))
        H7_REJECT("commitment_curve_reconstruction");
""",
    ),
    (
        """    verify = mp_compare(sig->chall_coeff, chk_chall, NWORDS_ORDER) == 0;

    return verify;
""",
        """    verify = mp_compare(sig->chall_coeff, chk_chall, NWORDS_ORDER) == 0;

    if (!verify)
        fprintf(stderr, "H7_REJECT=challenge_hash_mismatch\\n");
    return verify;
""",
    ),
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    args = parser.parse_args()

    original_bytes = args.source.read_bytes()
    text = original_bytes.decode("utf-8")

    for index, (old, new) in enumerate(REPLACEMENTS, start=1):
        count = text.count(old)
        if count != 1:
            raise SystemExit(
                f"replacement {index} expected exactly one upstream match, found {count}"
            )
        text = text.replace(old, new, 1)

    modified_bytes = text.encode("utf-8")
    args.source.write_bytes(modified_bytes)
    print(f"source={args.source}")
    print(f"original_sha256={sha256(original_bytes)}")
    print(f"instrumented_sha256={sha256(modified_bytes)}")
    print(f"replacement_count={len(REPLACEMENTS)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
