#include <api.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

struct request_header { uint64_t pk_length, signed_message_length; };
struct response_header {
    int32_t result, accepted;
    uint64_t recovered_length, expected_length;
    uint32_t stderr_length;
};

static int transfer(int fd, void *buffer, size_t length, int writing) {
    unsigned char *cursor = buffer;
    while (length != 0) {
        ssize_t count = writing ? write(fd, cursor, length) : read(fd, cursor, length);
        if (count <= 0) return 0;
        cursor += count;
        length -= (size_t)count;
    }
    return 1;
}

int main(int argc, char **argv) {
    struct sockaddr_un address = {0};
    int listener;
    if (argc != 2 || strlen(argv[1]) >= sizeof(address.sun_path)) return 2;
    listener = socket(AF_UNIX, SOCK_STREAM, 0);
    address.sun_family = AF_UNIX;
    strcpy(address.sun_path, argv[1]);
    unlink(address.sun_path);
    if (listener < 0 || bind(listener, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        listen(listener, 8) != 0) return 2;
    for (;;) {
        struct request_header request;
        struct response_header response = {.result = 2};
        unsigned char *pk = NULL, *sm = NULL, *message = NULL;
        char trace[4096] = {0};
        unsigned long long recovered_length = 0;
        int connection = accept(listener, NULL, NULL);
        int trace_pipe[2], saved_stderr = -1;
        if (connection < 0) continue;
        if (!transfer(connection, &request, sizeof(request), 0) ||
            request.pk_length != CRYPTO_PUBLICKEYBYTES ||
            request.signed_message_length < CRYPTO_BYTES ||
            request.signed_message_length > SIZE_MAX) goto respond;
        pk = malloc((size_t)request.pk_length + 1);
        sm = malloc((size_t)request.signed_message_length + 1);
        response.expected_length = request.signed_message_length - CRYPTO_BYTES;
        message = malloc((size_t)response.expected_length + 1);
        if (pk == NULL || sm == NULL || message == NULL ||
            !transfer(connection, pk, (size_t)request.pk_length, 0) ||
            !transfer(connection, sm, (size_t)request.signed_message_length, 0)) goto respond;
        if (pipe(trace_pipe) != 0) goto respond;
        saved_stderr = dup(STDERR_FILENO);
        if (saved_stderr < 0 || dup2(trace_pipe[1], STDERR_FILENO) < 0) goto restore;
        close(trace_pipe[1]);
        response.result = crypto_sign_open(message, &recovered_length, sm,
                                           request.signed_message_length, pk);
        response.recovered_length = recovered_length;
        fflush(stderr);
        dup2(saved_stderr, STDERR_FILENO);
        close(saved_stderr);
        saved_stderr = -1;
        {
            ssize_t trace_count = read(trace_pipe[0], trace, sizeof(trace) - 1);
            response.stderr_length = trace_count > 0 ? (uint32_t)trace_count : 0;
        }
        close(trace_pipe[0]);
        response.accepted = response.result == 0 &&
            response.recovered_length == response.expected_length &&
            memcmp(message, sm + CRYPTO_BYTES, (size_t)response.expected_length) == 0;
        goto respond;
restore:
        if (saved_stderr >= 0) { dup2(saved_stderr, STDERR_FILENO); close(saved_stderr); }
        close(trace_pipe[0]); close(trace_pipe[1]);
respond:
        transfer(connection, &response, sizeof(response), 1);
        if (response.stderr_length != 0)
            transfer(connection, trace, response.stderr_length, 1);
        free(pk); free(sm); free(message); close(connection);
    }
}
